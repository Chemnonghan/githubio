<?php
/* Theme default settings */
return array(
    'name' => 'Default',
    'header_bg_color' => '#769E51',
    'warpper_bg_color' => '#F9F9F9',
    'content_bg' => '#FFFFFF',
    'header_color' => '#FFFFFF',
    'footer_color' => '#7E7E7E',
    'logo_color' => '#FFFFFF',
    'login_header_color' => '#FFFFFF',
    'login_footer_color' => '#FFFFFF',
    'login_color' => '#FFFFFF',
    'login_bg_color' => '#769E51',
    'theme_width' => 'default'
);
